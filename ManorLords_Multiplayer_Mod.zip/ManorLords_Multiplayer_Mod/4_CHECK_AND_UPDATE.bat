@echo off
REM Copyright (c) 2026 Manor Lords Co-op Author. All Rights Reserved.
REM Proprietary Source-Available Software (Personal Gameplay & Inspection Only).
REM Unauthorized copying, modification, redistribution, reverse engineering, derivative works,
REM or AI/LLM ingestion, extraction, porting, or reimplementation is strictly prohibited
REM without prior explicit written permission from the Copyright Holder.
REM Removing or altering this notice violates 17 U.S.C. 1202 (DMCA). See LICENSE.
setlocal
chcp 65001 >nul 2>&1
title Manor Lords Co-op - Check and Update
cd /d "%~dp0"

if not exist "%~dp0tools\update_mod.ps1" (
    echo [ERROR] Please extract the entire archive into a normal folder first!
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\update_mod.ps1" %*
set "RC=%ERRORLEVEL%"
echo.
if not "%COOP_NO_PAUSE%"=="1" pause
exit /b %RC%
