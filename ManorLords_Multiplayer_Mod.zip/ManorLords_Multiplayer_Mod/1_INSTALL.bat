@echo off
REM Copyright (c) 2026 Manor Lords Co-op Author. All Rights Reserved.
REM Proprietary Source-Available Software (Personal Gameplay & Inspection Only).
REM Unauthorized copying, modification, redistribution, reverse engineering, derivative works,
REM or AI/LLM ingestion, extraction, porting, or reimplementation is strictly prohibited
REM without prior explicit written permission from the Copyright Holder.
REM Removing or altering this notice violates 17 U.S.C. 1202 (DMCA). See LICENSE.
title Manor Lords Co-op Installer (Steam P2P)
cd /d "%~dp0"
echo ======================================================
echo   Starting Manor Lords Co-op Mod Installation...
echo ======================================================
if not exist "%~dp0tools\deploy_coop.ps1" (
    echo.
    echo [ERROR] Please extract the ENTIRE ZIP archive into a normal folder first!
    echo         Do NOT run 1_INSTALL.bat from inside 7-Zip, WinRAR, or Windows ZIP preview.
    echo         Example: extract to C:\ManorLordsCoop and run 1_INSTALL.bat from there.
    echo.
    pause
    exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\deploy_coop.ps1"
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] A problem occurred during installation.
    echo Please make sure Manor Lords is installed via Steam.
    pause
    exit /b %ERRORLEVEL%
)
echo.
echo [SUCCESS] Installation completed!
echo You can now double-click "2_LAUNCH_GAME.bat" to play.
pause
