@echo off
REM Copyright (c) 2026 Manor Lords Co-op Author. All Rights Reserved.
REM Proprietary Source-Available Software (Personal Gameplay & Inspection Only).
REM Unauthorized copying, modification, redistribution, reverse engineering, derivative works,
REM or AI/LLM ingestion, extraction, porting, or reimplementation is strictly prohibited
REM without prior explicit written permission from the Copyright Holder.
REM Removing or altering this notice violates 17 U.S.C. 1202 (DMCA). See LICENSE.
setlocal
chcp 65001 >nul 2>&1
title Manor Lords Multiplayer - Log Collector

set "CALLER_DIR=%~dp0"
if "%CALLER_DIR:~-1%"=="\" set "CALLER_DIR=%CALLER_DIR:~0,-1%"
set "PS_SCRIPT=%CALLER_DIR%\tools\collect_logs.ps1"

if exist "%PS_SCRIPT%" goto :run_ps

REM Fallback: if the user copied this .bat into the Manor Lords game folder, locate tools\collect_logs.ps1 via daemon_path.lua
set "DAEMON_LUA="
if exist "%CALLER_DIR%\ManorLords\Binaries\Win64\ue4ss\Mods\ManorLordsCoop\Scripts\daemon_path.lua" set "DAEMON_LUA=%CALLER_DIR%\ManorLords\Binaries\Win64\ue4ss\Mods\ManorLordsCoop\Scripts\daemon_path.lua"
if not defined DAEMON_LUA if exist "%CALLER_DIR%\ue4ss\Mods\ManorLordsCoop\Scripts\daemon_path.lua" set "DAEMON_LUA=%CALLER_DIR%\ue4ss\Mods\ManorLordsCoop\Scripts\daemon_path.lua"
if defined DAEMON_LUA (
    for /f "usebackq delims=" %%R in (`powershell -NoProfile -Command "$t=Get-Content -LiteralPath $env:DAEMON_LUA -Raw -ErrorAction SilentlyContinue; if($t -match 'repo_root\s*=\s*\[\[([^\]]+)\]\]'){ $Matches[1] }"`) do (
        if exist "%%R\tools\collect_logs.ps1" set "PS_SCRIPT=%%R\tools\collect_logs.ps1"
    )
)

if exist "%PS_SCRIPT%" goto :run_ps

REM Pure standalone fallback (works even if ONLY this .bat file was copied anywhere on disk)
powershell -NoProfile -ExecutionPolicy Bypass -Command "& { $ErrorActionPreference='Continue'; $ts=Get-Date -Format 'yyyyMMdd_HHmmss'; $ipc=Join-Path $env:LOCALAPPDATA 'ManorLords\Saved\CoopIPC'; $cl=Join-Path $env:LOCALAPPDATA 'ManorLords\Saved\CoopLogs'; $cr=Join-Path $env:LOCALAPPDATA 'ManorLords\Saved\Crashes'; $st=Join-Path $env:TEMP ('ManorLords_SyncLog_'+$ts); New-Item -ItemType Directory -Path $st -Force | Out-Null; if(Test-Path -LiteralPath $ipc){ Get-ChildItem -LiteralPath $ipc -Filter 'sync_trace_*.jsonl' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1 | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $st -Force }; foreach($f in @('daemon.log','native_status.json','coop_config.json')){ $p=Join-Path $ipc $f; if(Test-Path -LiteralPath $p){ Copy-Item -LiteralPath $p -Destination $st -Force } } }; if(Test-Path -LiteralPath $cl){ Get-ChildItem -LiteralPath $cl -Filter 'sync_dump_*.json' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 5 | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $st -Force } }; if(Test-Path -LiteralPath $cr){ $lc=Get-ChildItem -LiteralPath $cr -Directory -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1; if($lc){ foreach($cf in @('CrashContext.runtime-xml','ManorLords.log')){ $cp=Join-Path $lc.FullName $cf; if(Test-Path -LiteralPath $cp){ Copy-Item -LiteralPath $cp -Destination $st -Force } } } }; foreach($u in @((Join-Path $env:CALLER_DIR 'UE4SS.log'),(Join-Path $env:CALLER_DIR 'ue4ss\UE4SS.log'),(Join-Path $env:CALLER_DIR 'ManorLords\Binaries\Win64\ue4ss\UE4SS.log'))){ if(Test-Path -LiteralPath $u){ Copy-Item -LiteralPath $u -Destination (Join-Path $st 'UE4SS.log') -Force; break } }; $d=[Environment]::GetFolderPath('Desktop'); $ok=$false; if($d -and (Test-Path -LiteralPath $d)){ try { $pr=Join-Path $d ('.ml_probe_'+$PID+'.tmp'); [System.IO.File]::WriteAllText($pr,'ok'); Remove-Item -LiteralPath $pr -Force; $ok=$true } catch {} }; if(-not $ok){ $d=$cl; New-Item -ItemType Directory -Path $d -Force | Out-Null }; $zip=Join-Path $d ('ManorLords_SyncLog_'+$ts+'.zip'); Add-Type -AssemblyName System.IO.Compression.FileSystem; if(Test-Path -LiteralPath $zip){ Remove-Item -LiteralPath $zip -Force }; [System.IO.Compression.ZipFile]::CreateFromDirectory($st,$zip); Remove-Item -LiteralPath $st -Recurse -Force -ErrorAction SilentlyContinue; Write-Host ('[SUCCESS] Logs saved to: ' + $zip); $q=[char]34; if($env:COOP_NO_OPEN -ne '1'){ Start-Process explorer.exe -ArgumentList ('/select,' + $q + $zip + $q) } }"
echo.
if not "%COOP_NO_PAUSE%"=="1" pause
exit /b %ERRORLEVEL%

:run_ps
if "%COOP_NO_OPEN%"=="1" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%" -Arg1 "%~1" -Arg2 "%~2" -CallerDir "%CALLER_DIR%" -NoOpen
) else (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%" -Arg1 "%~1" -Arg2 "%~2" -CallerDir "%CALLER_DIR%"
)
echo.
if not "%COOP_NO_PAUSE%"=="1" pause
exit /b %ERRORLEVEL%
