@echo off
REM Copyright (c) 2026 Manor Lords Co-op Author. All Rights Reserved.
REM Proprietary Source-Available Software (Personal Gameplay & Inspection Only).
REM Unauthorized copying, modification, redistribution, reverse engineering, derivative works,
REM or AI/LLM ingestion, extraction, porting, or reimplementation is strictly prohibited
REM without prior explicit written permission from the Copyright Holder.
REM Removing or altering this notice violates 17 U.S.C. 1202 (DMCA). See LICENSE.
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1

set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "NODE=%ROOT%\runtime\node.exe"
if not exist "%NODE%" set "NODE=node"
set "ANALYZER=%ROOT%\tools\analyze_sync_trace.mjs"

for /f "usebackq delims=" %%D in (`powershell -NoProfile -Command "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; [Environment]::GetFolderPath('Desktop')"`) do set "DESKTOP=%%D"
if "%DESKTOP%"=="" set "DESKTOP=%USERPROFILE%\Desktop"
for /f "usebackq delims=" %%T in (`powershell -NoProfile -Command "Get-Date -Format 'yyyyMMdd_HHmmss'"`) do set "TS=%%T"

echo ======================================================================
echo   MANOR LORDS MULTIPLAYER - FORENSIC LOG COLLECTOR AND ANALYZER
echo ======================================================================
echo.

REM --- MODE 2: If two .jsonl files are dragged and dropped, run Host vs Client DIFF ---
if not "%~2"=="" (
    set "TMPDIFF=%TEMP%\ManorLords_SyncDiff_%TS%.txt"
    echo [DIFF] 2 files detected:
    echo   1: %~1
    echo   2: %~2
    echo.
    "%NODE%" "%ANALYZER%" "%~1" "%~2" --out "%TMPDIFF%"
    if exist "%TMPDIFF%" (
        set "PS_SRC=%TMPDIFF%"
        set "PS_NAME=ManorLords_SyncDiff_%TS%.txt"
        powershell -NoProfile -Command "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; $d=[Environment]::GetFolderPath('Desktop'); if(-not $d -or -not (Test-Path -LiteralPath $d)){ $d=Join-Path $env:USERPROFILE 'Desktop' }; $dst=Join-Path $d $env:PS_NAME; Copy-Item -LiteralPath $env:PS_SRC -Destination $dst -Force; Write-Host ''; Write-Host '[OK] Host-vs-Client comparison report ready:'; Write-Host ('     ' + $dst); Write-Host ''; Start-Process notepad.exe -ArgumentList @($dst)"
    ) else (
        echo [ERROR] Could not generate analysis report!
    )
    pause
    exit /b 0
)

REM --- MODE 1B: If one .jsonl file is dragged and dropped, generate summary ---
if not "%~1"=="" (
    set "TMPSUM=%TEMP%\ManorLords_SyncSummary_%TS%.txt"
    echo [ANALYZE] Analyzing single file: %~1
    "%NODE%" "%ANALYZER%" "%~1" --out "%TMPSUM%"
    if exist "%TMPSUM%" (
        set "PS_SRC=%TMPSUM%"
        set "PS_NAME=ManorLords_SyncSummary_%TS%.txt"
        powershell -NoProfile -Command "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; $d=[Environment]::GetFolderPath('Desktop'); if(-not $d -or -not (Test-Path -LiteralPath $d)){ $d=Join-Path $env:USERPROFILE 'Desktop' }; $dst=Join-Path $d $env:PS_NAME; Copy-Item -LiteralPath $env:PS_SRC -Destination $dst -Force; Write-Host ('[OK] Summary report ready: ' + $dst); Start-Process notepad.exe -ArgumentList @($dst)"
    ) else (
        echo [ERROR] Could not generate summary report!
    )
    pause
    exit /b 0
)

REM --- MODE 1A: Double-click -> Collect all logs, generate summary, and ZIP to Desktop ---
set "IPC=%LOCALAPPDATA%\ManorLords\Saved\CoopIPC"
set "COOPLOGS=%LOCALAPPDATA%\ManorLords\Saved\CoopLogs"
set "STAGE=%TEMP%\ManorLords_SyncLog_%TS%"
mkdir "%STAGE%" >nul 2>&1

set "LATEST_TRACE="
if exist "%IPC%\sync_trace_latest.txt" (
    set /p LATEST_TRACE=<"%IPC%\sync_trace_latest.txt"
)
if not exist "%LATEST_TRACE%" (
    for /f "delims=" %%F in ('dir /b /a-d /o-d "%IPC%\sync_trace_*.jsonl" 2^>nul') do (
        if "!LATEST_TRACE!"=="" set "LATEST_TRACE=%IPC%\%%F"
    )
)

set "ROLE_TAG=LOG"
if exist "%LATEST_TRACE%" (
    echo [OK] Latest trace found: %LATEST_TRACE%
    copy /y "%LATEST_TRACE%" "%STAGE%\" >nul
    echo !LATEST_TRACE! | findstr /i "_host_" >nul && set "ROLE_TAG=HOST"
    echo !LATEST_TRACE! | findstr /i "_client_" >nul && set "ROLE_TAG=CLIENT"
    echo [ANALYZE] Generating automatic summary report...
    "%NODE%" "%ANALYZER%" "%LATEST_TRACE%" --out "%STAGE%\sync_summary.txt"
) else (
    echo [WARNING] No sync_trace_*.jsonl found in %IPC%!
    echo           Please launch the game with the multiplayer mod and start a match first.
)

if exist "%IPC%\daemon.log" copy /y "%IPC%\daemon.log" "%STAGE%\daemon.log" >nul
if exist "%IPC%\native_status.json" copy /y "%IPC%\native_status.json" "%STAGE%\native_status.json" >nul
for %%D in ("%IPC%\sync_dump_*.json" "%IPC%\sync_dump_*.txt") do (
    if exist "%%~fD" copy /y "%%~fD" "%STAGE%\" >nul
)
REM Copy up to 5 newest coordinated ring dumps from CoopLogs if present
set "DUMP_CNT=0"
if exist "%COOPLOGS%" (
    for /f "delims=" %%F in ('dir /b /a-d /o-d "%COOPLOGS%\sync_dump_*.json" 2^>nul') do (
        if !DUMP_CNT! LSS 5 (
            copy /y "%COOPLOGS%\%%F" "%STAGE%\%%F" >nul
            set /a DUMP_CNT+=1
        )
    )
)

REM Locate UE4SS.log (Steam libraries + libraryfolders.vdf auto-detect)
for %%P in (
    "E:\SteamLibrary\steamapps\common\Manor Lords\ManorLords\Binaries\Win64\ue4ss\UE4SS.log"
    "C:\Program Files (x86)\Steam\steamapps\common\Manor Lords\ManorLords\Binaries\Win64\ue4ss\UE4SS.log"
    "D:\SteamLibrary\steamapps\common\Manor Lords\ManorLords\Binaries\Win64\ue4ss\UE4SS.log"
    "F:\SteamLibrary\steamapps\common\Manor Lords\ManorLords\Binaries\Win64\ue4ss\UE4SS.log"
    "%IPC%\UE4SS.log"
) do (
    if not exist "%STAGE%\UE4SS.log" if exist %%P (
        echo [OK] UE4SS.log copied: %%~P
        copy /y %%P "%STAGE%\UE4SS.log" >nul
    )
)

REM Auto-collect UE4SS.log from any custom Steam library AND latest UE5 CrashContext.runtime-xml
set "PS_STAGE_EXTRA=%STAGE%"
powershell -NoProfile -Command "$stage=$env:PS_STAGE_EXTRA; if(-not (Test-Path (Join-Path $stage 'UE4SS.log'))){ $vdfs=@('C:\Program Files (x86)\Steam\steamapps\libraryfolders.vdf','C:\Program Files\Steam\steamapps\libraryfolders.vdf'); foreach($v in $vdfs){ if(Test-Path $v){ $txt=Get-Content -Raw $v -ErrorAction SilentlyContinue; foreach($m in [regex]::Matches($txt,'\"path\"\s+\"([^\"]+)\"')){ $lib=$m.Groups[1].Value -replace '\\\\','\'; $cand=Join-Path $lib 'steamapps\common\Manor Lords\ManorLords\Binaries\Win64\ue4ss\UE4SS.log'; if(Test-Path $cand){ Copy-Item -LiteralPath $cand -Destination (Join-Path $stage 'UE4SS.log') -Force; Write-Host ('[OK] UE4SS.log copied: ' + $cand); break } } } } }; $crashRoot=Join-Path $env:LOCALAPPDATA 'ManorLords\Saved\Crashes'; if(Test-Path $crashRoot){ $latest=Get-ChildItem -LiteralPath $crashRoot -Directory -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1; if($latest){ $xml=Join-Path $latest.FullName 'CrashContext.runtime-xml'; if(Test-Path $xml){ Copy-Item -LiteralPath $xml -Destination (Join-Path $stage 'CrashContext.runtime-xml') -Force; Write-Host ('[OK] Latest UE5 CrashContext copied: ' + $latest.Name) }; $mlog=Join-Path $latest.FullName 'ManorLords.log'; if(Test-Path $mlog){ Copy-Item -LiteralPath $mlog -Destination (Join-Path $stage 'Crash_ManorLords.log') -Force } } }"

set "PS_STAGE=%STAGE%"
set "PS_ROLE=%ROLE_TAG%"
set "PS_TS=%TS%"
echo.
echo ======================================================================
powershell -NoProfile -Command "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; $d=[Environment]::GetFolderPath('Desktop'); if(-not $d -or -not (Test-Path -LiteralPath $d)){ $d=Join-Path $env:USERPROFILE 'Desktop' }; $stage=$env:PS_STAGE; $role=$env:PS_ROLE; $ts=$env:PS_TS; $sumSrc=Join-Path $stage 'sync_summary.txt'; $sumDst=Join-Path $d ('ManorLords_SyncSummary_'+$role+'_'+$ts+'.txt'); if(Test-Path -LiteralPath $sumSrc){ Copy-Item -LiteralPath $sumSrc -Destination $sumDst -Force }; $zipDst=Join-Path $d ('ManorLords_SyncLog_'+$role+'_'+$ts+'.zip'); Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zipDst -Force; if(Test-Path -LiteralPath $zipDst){ Write-Host '[SUCCESS] All logs packaged:'; Write-Host ('  ZIP     : ' + $zipDst); if(Test-Path -LiteralPath $sumDst){ Write-Host ('  SUMMARY : ' + $sumDst) }; Write-Host ''; Write-Host '[TIP] Drag and drop both Host and Client .jsonl files onto this .bat'; Write-Host '      to automatically generate a Host-vs-Client DIFF report.' } else { Write-Host ('[ERROR] Could not create ZIP archive. Staging folder: ' + $stage); exit 1 }"
echo ======================================================================
echo.
pause
exit /b 0
