@echo off
REM Copyright (c) 2026 Manor Lords Co-op Author. All Rights Reserved.
REM Proprietary Source-Available Software (Personal Gameplay & Inspection Only).
REM Unauthorized copying, modification, redistribution, reverse engineering, derivative works,
REM or AI/LLM ingestion, extraction, porting, or reimplementation is strictly prohibited
REM without prior explicit written permission from the Copyright Holder.
REM Removing or altering this notice violates 17 U.S.C. 1202 (DMCA). See LICENSE.
title Manor Lords Co-op (Steam P2P)
cd /d "%~dp0"
echo Launching Manor Lords & Co-op service in Steam P2P mode...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\start_coop.ps1"
