#!/usr/bin/env bash
# Manor Lords Co-op Mod - Proprietary Software - All Rights Reserved.
# Copyright (c) 2026 Manor Lords Co-op Author. All Rights Reserved.
# NOT OPEN SOURCE. Strictly for personal, non-commercial gameplay and inspection only.
# Removing this notice violates 17 U.S.C. Sec. 1202 (DMCA). See LICENSE.
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
VER_FILE="$SCRIPT_DIR/version.json"
REPO="p3pabaddon/manor-lords-multiplayer"
MANIFEST_URL="${1:-https://raw.githubusercontent.com/$REPO/main/latest.json}"

echo "======================================================================"
echo "  MANOR LORDS CO-OP MOD - ONE-CLICK UPDATER (Linux / Steam Deck)"
echo "======================================================================"

if ! command -v python3 >/dev/null 2>&1; then
    echo "[ERROR] python3 is required to check and apply updates."
    exit 1
fi

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

python3 - "$SCRIPT_DIR" "$VER_FILE" "$MANIFEST_URL" "$TMP_DIR" <<'PY'
import hashlib, json, os, re, shutil, sys, urllib.request, zipfile

root, ver_file, manifest_url, tmp_dir = sys.argv[1:5]
local_ver = "0.0.0"
if os.path.isfile(ver_file):
    try:
        local_ver = json.load(open(ver_file, encoding="utf-8")).get("version", "0.0.0")
    except Exception:
        pass

def ver_key(v):
    m = re.match(r"^[vV]?(\d+)\.(\d+)\.(\d+)([a-zA-Z]*)$", str(v).strip())
    if not m: return (0, 0, 0, 0)
    suf = sum((ord(c) - 96) * (27 ** i) for i, c in enumerate(reversed(m.group(4).lower())))
    return (int(m.group(1)), int(m.group(2)), int(m.group(3)), suf)

print(f"Installed version: v{local_ver}")
if os.path.isfile(manifest_url):
    remote = json.load(open(manifest_url, encoding="utf-8"))
else:
    req = urllib.request.Request(manifest_url, headers={"User-Agent": "ManorLordsCoop-Updater/1.0"})
    with urllib.request.urlopen(req, timeout=15) as r:
        remote = json.loads(r.read().decode("utf-8"))

rver = str(remote.get("version", "")).lstrip("vV")
if ver_key(local_ver) >= ver_key(rver):
    print(f"[OK] Already up to date (v{local_ver}).")
    sys.exit(0)

print(f"[UPDATE AVAILABLE] v{local_ver} -> v{rver}")
if remote.get("notes"):
    print(remote["notes"])

min_base = remote.get("minBaseVersion", "1.0.8")
has_rt = os.path.isfile(os.path.join(root, "ue4ss_bundle", "ue4ss", "UE4SS.dll"))
use_patch = has_rt and bool(remote.get("patchUrl")) and ver_key(local_ver) >= ver_key(min_base)
url = remote["patchUrl"] if use_patch else remote["fullUrl"]
sha = (remote.get("patchSha256") if use_patch else remote.get("fullSha256")) or ""

zip_path = os.path.join(tmp_dir, "update.zip")
print(f"Downloading {'Fast Patch' if use_patch else 'Full Archive'}...")
if os.path.isfile(url):
    shutil.copyfile(url, zip_path)
else:
    req = urllib.request.Request(url, headers={"User-Agent": "ManorLordsCoop-Updater/1.0"})
    with urllib.request.urlopen(req, timeout=120) as r, open(zip_path, "wb") as out:
        shutil.copyfileobj(r, out)

if sha:
    actual = hashlib.sha256(open(zip_path, "rb").read()).hexdigest().upper()
    if actual != sha.strip().upper():
        raise SystemExit(f"[ERROR] SHA-256 mismatch: expected {sha}, got {actual}")
    print("SHA-256 verified OK.")

ext_dir = os.path.join(tmp_dir, "extracted")
with zipfile.ZipFile(zip_path) as zf:
    zf.extractall(ext_dir)

payload = os.path.join(ext_dir, "ManorLords_Multiplayer_Mod")
if not os.path.isdir(payload):
    payload = ext_dir

for dirpath, _, filenames in os.walk(payload):
    rel_dir = os.path.relpath(dirpath, payload)
    dst_dir = root if rel_dir == "." else os.path.join(root, rel_dir)
    os.makedirs(dst_dir, exist_ok=True)
    for fn in filenames:
        shutil.copy2(os.path.join(dirpath, fn), os.path.join(dst_dir, fn))

print(f"[OK] Files updated to v{rver}.")
PY

if [ -f "$SCRIPT_DIR/1_INSTALL_LINUX.sh" ]; then
    echo "[DEPLOY] Re-deploying into Proton / Steam folder..."
    bash "$SCRIPT_DIR/1_INSTALL_LINUX.sh"
fi
echo "[SUCCESS] Update complete!"
